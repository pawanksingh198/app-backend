export const steps = [
  {
    title: 'addons',
    content: 'First-content',
  },
  {
    title: 'stocks',
    content: 'Third-content',
  },
  {
    title: 'finish',
    content: 'Finish-content',
  },
];
