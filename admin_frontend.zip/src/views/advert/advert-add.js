import React from 'react'
import AdvertForm from './advert-form'

const AddvertAdd = () => {
  return (
    <AdvertForm />
  )
}

export default AddvertAdd