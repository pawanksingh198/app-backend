export default function AdvertIndex() {
  return <div>advert index</div>;
}
