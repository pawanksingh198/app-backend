import React from 'react';
import {PlusOutlined} from "@ant-design/icons";

export const uploadButton = (
    <div>
        <PlusOutlined/>
        <div style={{marginTop: 8}}>Upload</div>
    </div>
);