export const colLg = {
    xs: 12,
    sm: 12,
    md: 8,
    lg: 8,
    xxl: 4,
    xl: 6,
}